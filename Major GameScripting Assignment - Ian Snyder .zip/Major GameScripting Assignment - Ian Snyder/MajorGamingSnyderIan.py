# CMIS226 - Assgignment 1
# Name: Ian Snyder
# Project Title: KanGO Adventure
# Project Desciption: A Platformer Side Scroller

import pygame
from pygame.locals import *

#Game 
FPS = 30
WINDOWWIDTH = 1500
WINDOWHEIGHT = 600
HALF_WINWIDTH = int(WINDOWWIDTH / 2)
HALF_WINHEIGHT = int(WINDOWHEIGHT / 2)

pygame.init()

# Colors
WHITE =        (  0,   0,   0)
BRIGHTBLUE   = (  0,   0, 255)
RED          = (155,   0,   0)
GREEN        = (  0, 155,   0)
BLUE         = (  0,   0, 255)
BLACK        = (  0,   0,   0)
BGCOLOR = BRIGHTBLUE

#player
MOVESPEED = 3
JUMPHEIGHT = 6
isLookLeft = False
pygame.image.load('hopper-the-kangaroo.png')
R_K_IMG = pygame.transform.scale(pygame.image.load('hopper-the-kangaroo.png'), (60, 80))
L_K_IMG = pygame.transform.flip(R_K_IMG, True, False)
R_KICKED_IMG = pygame.transform.scale(pygame.image.load('kangaroo-kick.png'), (80, 80))
Y_K_IDLE = WINDOWHEIGHT - 28
Y_K_JUMP = Y_K_IDLE - 150

# flag
FLAG_GOAL_IMG = pygame.transform.scale(pygame.image.load('Flag.png'), (35, 50))
FLAG_SPAWN_POS_RIGHT = WINDOWWIDTH * 2
FLAG_BASELINE_Y = WINDOWHEIGHT - 26
FLAG_GAMEOVER_POS_RIGHT = HALF_WINWIDTH 


# Enemys
pygame.image.load('Dingo.webp')
DINGO_IMG = pygame.transform.scale(pygame.image.load('Dingo.webp'), (60, 80))
DINGO_SPAWN_POS_RIGHT = WINDOWWIDTH * 1.5
DINGO_BASELINE_Y = WINDOWHEIGHT - 16
pygame.image.load('poacher.jpg')
POACHER_IMG = pygame.transform.scale(pygame.image.load('poacher.jpg'), (60, 80))
POACHER_SPAWN_POS_RIGHT = WINDOWWIDTH
POACHER_BASELINE_Y = WINDOWHEIGHT - 26
ENEMY_GAMEOVER_POS_RIGHT = HALF_WINWIDTH


# Props
pygame.image.load('flower.png')
FLOWER_IMG = pygame.transform.scale(pygame.image.load('flower.png'), (35, 50))
FLOWER_SPAWN_POS_RIGHT = WINDOWWIDTH * 0.5
FLOWER_BASELINE_Y = WINDOWHEIGHT - 20
pygame.image.load('place-holder-leaf.png')
LEAF_IMG = pygame.transform.scale(pygame.image.load('place-holder-leaf.png'), (35, 50))
LEAF_SPAWN_POS_RIGHT = WINDOWWIDTH * 1.3
LEAF_BASELINE_Y = WINDOWHEIGHT - 30

# font
BASICFONT = pygame.font.Font('freesansbold.ttf', 32)
HOPPER_WIN = BASICFONT.render('Hopper Wins Again!!!', True, WHITE)
HOPPER_WIN_RECT = HOPPER_WIN.get_rect()
HOPPER_WIN_RECT.center = (HALF_WINWIDTH, HALF_WINHEIGHT)
HOPPER_LOSE = BASICFONT.render('Hopper Loses, GAME OVER!!!', True, WHITE)
HOPPER_LOSE_RECT = HOPPER_LOSE.get_rect()
HOPPER_LOSE_RECT.center = (HALF_WINWIDTH, HALF_WINHEIGHT)

DISPLAYSURF = pygame.display.set_mode((WINDOWWIDTH, WINDOWHEIGHT))

pygame.display.set_caption('KanGO Adventure')

#define game variables
tile_size = 50

#load images
bg_img = pygame.image.load('sky-background.png')

def draw_grid():
    for line in range(0, 20):
        pygame.draw.line(DISPLAYSURF, (255, 255, 255), (0, line * tile_size), (WINDOWWIDTH, line * tile_size))
        pygame.draw.line(DISPLAYSURF, (255, 255, 255), (line * tile_size, 0), (line * tile_size, WINDOWHEIGHT))


class Player():
    def __init__(self, x, y):
        self.image = R_K_IMG
        self.rect = self.image.get_rect()
        self.rect.x = HALF_WINWIDTH
        self.rect.y = Y_K_IDLE
        self.gravity = 0
        self.vel_y = 0
        self.jumped = False
        self.isLookLeft = False
        self.lost_game = False
        self.won_game = False
        self.game_over = False

        # Flag
        self.goal_image = FLAG_GOAL_IMG
        self.goal_rect = self.goal_image.get_rect()
        self.goal_rect.bottom = FLAG_BASELINE_Y
        self.goal_rect.right = FLAG_SPAWN_POS_RIGHT
        self.goal_offset = 0

        # Enemys
        self.dingo_image = DINGO_IMG
        self.dingo_rect = self.dingo_image.get_rect()
        self.dingo_rect.bottom = DINGO_BASELINE_Y
        self.dingo_rect.right = DINGO_SPAWN_POS_RIGHT
        self.dingo_offset = 0
        self.poacher_image = POACHER_IMG
        self.poacher_rect = self.poacher_image.get_rect()
        self.poacher_rect.bottom = POACHER_BASELINE_Y
        self.poacher_rect.right = POACHER_SPAWN_POS_RIGHT
        self.poacher_offset = 0

        # Props
        self.flower_image = FLOWER_IMG
        self.flower_rect = self.flower_image.get_rect()
        self.flower_rect.bottom = FLOWER_BASELINE_Y
        self.flower_rect.right = FLOWER_SPAWN_POS_RIGHT
        self.flower_offset = 0
        self.leaf_image = LEAF_IMG
        self.leaf_rect = self.leaf_image.get_rect()
        self.leaf_rect.bottom = LEAF_BASELINE_Y
        self.leaf_rect.right = LEAF_SPAWN_POS_RIGHT
        self.leaf_offset = 0




    def updateCharacterSprite(self):
        if self.isLookLeft == True:
            self.image = L_K_IMG

        if self.isLookLeft == False:
            self.image = R_K_IMG
    
    def calc_gravity(self):
        self.gravity += (3.2 / 100)
        
    def update(self):
        # direction key functions
        key = pygame.key.get_pressed()

        # Jump
        if key[pygame.K_SPACE] and self.jumped == False:
            self.jumped = True
            self.rect.bottom = Y_K_JUMP
        if key[pygame.K_LEFT]:
            self.isLookLeft = True
            self.updateCharacterSprite()
            self.goal_offset -= (1 + MOVESPEED)
            self.dingo_offset -= (1 + MOVESPEED)
            self.poacher_offset -= (1 + MOVESPEED)
            self.flower_offset -= (1 + MOVESPEED)
            self.leaf_offset -= (1 + MOVESPEED)
        if key[pygame.K_RIGHT]:
            self.isLookLeft = False
            self.updateCharacterSprite()
            self.goal_offset += (1 + MOVESPEED)
            self.dingo_offset += (1 + MOVESPEED)
            self.poacher_offset += (1 + MOVESPEED)
            self.flower_offset += (1 + MOVESPEED)
            self.leaf_offset += (1 + MOVESPEED)
        if key[pygame.K_k]:
            self.image = R_KICKED_IMG
            DISPLAYSURF.blit(self.image, self.rect)

        if self.jumped == True:
            self.rect.bottom += self.gravity
            self.calc_gravity()

        if self.rect.bottom > Y_K_IDLE and self.gravity >= 0:
            self.jumped = False
            self.rect.bottom = Y_K_IDLE
            self.gravity = 0
        
        # Set flag position
        self.goal_rect.right = FLAG_SPAWN_POS_RIGHT - self.goal_offset
        
        DISPLAYSURF.blit(self.image, self.rect)
        DISPLAYSURF.blit(self.goal_image, self.goal_rect)

        # Set Enemys position
        self.dingo_rect.right = DINGO_SPAWN_POS_RIGHT - self.dingo_offset
        self.poacher_rect.right = POACHER_SPAWN_POS_RIGHT - self.poacher_offset

        DISPLAYSURF.blit(self.dingo_image, self.dingo_rect)
        DISPLAYSURF.blit(self.poacher_image, self.poacher_rect)

        # Set Prop position
        self.flower_rect.right = FLOWER_SPAWN_POS_RIGHT - self.flower_offset
        self.leaf_rect.right = LEAF_SPAWN_POS_RIGHT - self.leaf_offset

        DISPLAYSURF.blit(self.flower_image, self.flower_rect)
        DISPLAYSURF.blit(self.leaf_image, self.leaf_rect)


        self.detectGameOver()

    def detectGameOver(self):
        if self.game_over == False and self.goal_rect.left < FLAG_GAMEOVER_POS_RIGHT:
            self.won_game = True
        if self.game_over == False and self.poacher_rect.left <= self.rect.right and self.poacher_rect.left >= self.rect.left and self.poacher_rect.top <= self.rect.bottom:
            self.lost_game = True
        if self.game_over == False and self.dingo_rect.left <= self.rect.right and self.dingo_rect.left >= self.rect.left and self.dingo_rect.top <= self.rect.bottom:
            self.lost_game = True
        
        if (self.won_game == True):
            self.lost_game = False
            self.game_over = True
            DISPLAYSURF.blit(HOPPER_WIN, HOPPER_WIN_RECT)
        
        if (self.lost_game == True):
            self.won_game = False
            self.game_over = True
            DISPLAYSURF.blit(HOPPER_LOSE, HOPPER_LOSE_RECT)
    
        

class World():
    def __init__(self, data):
        self.tile_list = []

        #load images for world
        grass_floor = pygame.image.load('grass-floor.png')


        # code for the tiles used in the game
        row_count = 0
        for row in data:
            col_count = 0
            for tile in row:
                if tile == 1:
                    img = pygame.transform.scale(grass_floor, (tile_size, tile_size))
                    img_rect = img.get_rect()
                    img_rect.x = col_count * tile_size
                    img_rect.y = row_count * tile_size
                    tile = (img, img_rect)
                    self.tile_list.append(tile)
                col_count += 1
            row_count += 1


    # code to draw the tiles used in the game
    def draw(self):
        for tile in self.tile_list:
            DISPLAYSURF.blit(tile[0], tile[1])
    

#data for the level
world_data = [
[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], 
]



player = Player(100, WINDOWHEIGHT - 130)
world = World(world_data)

run = True
while run:


    DISPLAYSURF.blit(bg_img, (0, 0))
    

    world.draw()

    player.update()


    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    pygame.display.update()

pygame.quit()