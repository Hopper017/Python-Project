# CMIS226 - Assgignment 1
# Name: Ian Snyder
# Project Title: KanGO Adventure
# Project Desciption: A Platformer Side Scroller


import pygame, sys
from pygame.locals import *

pygame.init()

# set up the window
DISPLAYSURF = pygame.display.set_mode((1500, 600), 0, 32)
pygame.display.set_caption('Game Scripting Assignment 1')

# set up the colors
BLACK = (  0,   0,   0)
WHITE = (255, 255, 255)
RED   = (255,   0,   0)
GREEN = (0, 100, 0)
BLUE  = (  0,   0, 255)

# draw on the surface object
DISPLAYSURF.fill(WHITE)

# set display fonts - NOTE: print(pygame.font.get_fonts()) will print the fonts on the system
font = pygame.font.SysFont('arialblack', 24)
font2 = pygame.font.SysFont('couriernew', 16)

# describe your project
course = font.render("CMIS226 Assignment 1", True, RED)
name = font.render("Your Name: Ian Snyder", True, BLUE)
title = font.render("Project Title: KanGO Adventure", True, GREEN)
desc1 = font2.render("Description Line 1: Are you ready to hop your way into a new adventure?", True, BLACK)
desc2 = font2.render("Description Line 2: Jump, Punch and Kick your way to victory!", True, BLACK)
desc3 = font2.render("Description Line 3: Collect Fruits, Leaves and Flowers to give you an edge against the evil poachers and dingoes.", True, BLACK)

# display the intro splash page
DISPLAYSURF.blit(course, (20,20))
pygame.draw.line(DISPLAYSURF, RED, (20, 55), (325, 55), 4)
DISPLAYSURF.blit(name, (20,70))
DISPLAYSURF.blit(title, (20,110))
DISPLAYSURF.blit(desc1, (20,150))
DISPLAYSURF.blit(desc2, (20,170))
DISPLAYSURF.blit(desc3, (20,190))

# run the game loop
while True:
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()
    pygame.display.update()
